def main():
    print("¡Hola desde Cobra!")


if __name__ == '__main__':
    main()
