.. Proyecto Cobra documentation master file, created by
   sphinx-quickstart on Tue Oct 15 19:07:40 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Cobra: Documentacion del Lenguaje de Programacion
===============================================

Cobra es un lenguaje de programacion experimental completamente en espanol, disenado para ser versatil y adecuado para tareas de alto, medio y bajo nivel. Su objetivo es proporcionar un entorno amigable para la simulacion, visualizacion y manipulacion de datos complejos, como los holobits, asi como para la programacion estandar en entornos modernos.

Cobra: Documentacion del Lenguaje de Programacion
===============================================

Cobra es un lenguaje de programacion experimental completamente en espanol, disenado para ser versatil y adecuado para tareas de alto, medio y bajo nivel. Su objetivo es proporcionar un entorno amigable para la simulacion, visualizacion y manipulacion de datos complejos, como los holobits, asi como para la programacion estandar en entornos modernos.

.. toctree::
   :maxdepth: 2
   :caption: Contenidos:

   caracteristicas
   sintaxis
   avances
   proximos_pasos

Introducción
--------------------

Cobra fue creado con la idea de facilitar la programacion en español, optimizando la gestion de memoria y anadiendo soporte para trabajar con datos de alta complejidad como los holobits. Ademas, ofrece soporte para transpilar a Python y JavaScript, permitiendo su ejecucion en multiples plataformas.




