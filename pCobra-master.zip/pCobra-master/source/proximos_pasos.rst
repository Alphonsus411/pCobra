Proximos pasos para Cobra
==========================

- Expandir las funcionalidades para holobits.
- Mejorar el sistema de simulacion y visualizacion.
- Implementar nuevas optimizaciones para un mejor rendimiento en simulaciones complejas.
